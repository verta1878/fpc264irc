# CREDITS — fpc264irc r3.1

## The Crew

| Handle | Name | Role |
|--------|------|------|
| verta1878 | Antonio Rico | Project lead, architect |
| sysop/0 | — | fpc264irc maintainer, compiler engineer |
| evga | — | Display, Mystic monitor, marc-lib, repo cleanup |
| kiddo | — | marc-lib archive library |
| wrench | — | Build machine, PPU chain verification |

## Standing on the shoulders of:

| Who | What |
|-----|------|
| Florian Klämpfl | Free Pascal Compiler |
| James Coyle | Mystic BBS |
| Ian Davis | TheDraw |
| David Muir (PainSoft) | THD ProScan |
| Joaquim Homrighausen | FrontDoor |
| Eberhard Mattes | EMX 0.9d |
| Jeff Reeder (TeleGrafix) | RIPscrip, RIPaint |
| Quarterdeck / IBM | DESQview + QEMM |

## License

GPLv3 — because the code should outlive us all.

o7

# Phase D-5: Binary Comparison Report

## 1. emxbind Output Verification

Three independent implementations produce **identical output**:

| Implementation | SHA256 | Match |
|---------------|--------|-------|
| Pascal (emxbind.pas) | `1c47d0bf36538c1f69f1f8a41c41e39e5c4b7f855cb65bdf8aa605cb2c952960` | ✅ |
| Python (inline) | `1c47d0bf36538c1f69f1f8a41c41e39e5c4b7f855cb65bdf8aa605cb2c952960` | ✅ |
| C (emxbind.c) | `1c47d0bf36538c1f69f1f8a41c41e39e5c4b7f855cb65bdf8aa605cb2c952960` | ✅ |

All three produce byte-identical output. Verified with `cmp` and `sha256sum`.

## 2. Cross-Platform Size Comparison

| Program | Linux ELF32 | OS/2 a.out | OS/2 MZ+a.out | Ratio |
|---------|------------|-----------|---------------|-------|
| mystic | 1,533,568 | 1,420,746 | 1,422,282 | 0.93x |
| mis | 1,400,292 | 1,243,007 | 1,244,543 | 0.89x |
| mutil | 2,066,916 | 1,900,189 | 1,901,725 | 0.92x |
| fidopoll | 1,280,900 | 1,136,795 | 1,138,331 | 0.89x |
| marc | 1,127,848 | 997,001 | 998,537 | 0.88x |
| nodespy | 863,860 | 762,870 | 764,406 | 0.88x |
| qwkpoll | 1,235,848 | 1,093,589 | 1,095,125 | 0.88x |
| mide | 563,428 | 513,768 | 515,304 | 0.91x |
| mbbsutil | 558,520 | 493,069 | 494,605 | 0.88x |
| mplc | 492,800 | 449,045 | 450,581 | 0.91x |
| install | 421,892 | 377,412 | 378,948 | 0.89x |
| 109to110 | 419,648 | 363,710 | 365,246 | 0.87x |
| mystpack | 409,504 | 354,580 | 356,116 | 0.87x |
| maketheme | 394,184 | 356,492 | 358,028 | 0.90x |
| install_make | 387,272 | 346,966 | 348,502 | 0.90x |

**Ratio range: 0.87x — 0.93x** (consistent across all programs).
OS/2 smaller because: no ELF overhead, no section headers, no dynamic linking stubs.
MZ+a.out adds 1,536 bytes (emxl.exe stub) over raw a.out.

## 3. Linux ELF Analysis

| Program | Total | .text | .data | .bss | Entry |
|---------|-------|-------|-------|------|-------|
| mystic | 1,533,568 | 874,416 | 144,028 | 19,284 | 0x0E57E0 |
| mis | 1,400,292 | 604,740 | 186,235 | 15,684 | 0x0A3C60 |
| mutil | 2,066,916 | 1,081,504 | 241,468 | 20,756 | 0x1180D0 |
| fidopoll | 1,280,900 | 539,440 | 176,044 | 15,972 | 0x093B60 |
| marc | 1,127,848 | 449,520 | 175,196 | 13,604 | 0x07DC20 |

All i386 ELF32, statically linked (except mis: dynamically linked).

## 4. OS/2 a.out Validation

All 15 programs validated:

| Check | Result |
|-------|--------|
| Magic 0x010B (ZMAGIC) | 15/15 ✅ |
| Machine type 0 | 15/15 ✅ |
| Entry 0x10000 | 15/15 ✅ |
| Startup: 68/E8/EB/E8 | 15/15 ✅ |
| Section consistency | 15/15 ✅ |
| MZ header (in .exe) | 15/15 ✅ |

## 5. SHA256 Checksums

### Linux (i386 ELF)
```
23b79df3a259e519766d8f7ab9ed36f036f31d8b8de6a3393db047f0eeee6aa0  mystic
dde8b4a1aac8fb630d4661df2638ba6ff18da5b23e6833804f611a21d93ac23d  mis
9362dab93eaaa62e6dd3a12e5e0a823722e6a768a56721c635250a615c9d651a  mutil
96cb71205dd625f57ab617bb5840229bf113c1521d12c4f349cdd1674767e422  fidopoll
31943ded779759937cfe2f1fbd8b96da37acad9f32094397a999fed288099950  marc
```

### OS/2 (MZ+a.out)
```
558900f0ce3006a72cc0c72ffe46a7ca913f7dc0e819198584c61ddc5a0f07e7  mystic.exe
566db709a700f9458051bd61e6f81b199881ca36a7a59c4d3eb5663bd1b60838  mis.exe
25901596f6da2082b991cd7b6323c786276b40ba8c207851b67c11286e8153f8  mutil.exe
6bd3ead7e1ebfd75c6ac81bfd54e3e81c47b069196d04ae17f99529ab263f570  fidopoll.exe
1c47d0bf36538c1f69f1f8a41c41e39e5c4b7f855cb65bdf8aa605cb2c952960  marc.exe
```

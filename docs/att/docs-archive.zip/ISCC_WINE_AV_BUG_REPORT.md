# ISCC.exe Wine AV — Post-Message Processing Crash

**Date:** 2026-07-20
**Binary:** ISCC.exe + ISCmplr.dll built against fpc264irc commit b7b5254f ("inno wine fix")
**Runtime:** Wine 9.0 + wine32:i386 on Ubuntu 24.04 x86_64
**Status:** AV persists after wine fix commit. Needs real Windows test.

---

## Summary

ISCC.exe crashes with Access Violation in post-message processing.
The crash persists after the fpc264irc "inno wine fix" commit
(b7b5254f). All resources are correctly embedded. PrepareSetupE32
and message parsing both succeed. The crash is after "Messages in
script file" — in PopulateLanguageEntryData, language codepage
handling, or the transition to file compression.

## Build Details

- fpc264irc: commit b7b5254f ("inno wine fix")
- RTL: 589 PPUs
- LCL: rebuilt from source (50 LazUtils + 37 base + 90 win32)
- fpcres: system FPC 3.2.2 fpcres (installed to toolchain)
- Source: innosetup-5_6_1-fpc-src_tar.gz (uploaded, good tarball)
- All 5 targets compile clean

## Binaries

| File | Size | Status |
|------|------|--------|
| ISCC.exe | 437KB | compiles, runs under Wine |
| ISCmplr.dll | 1.9MB | loads correctly |
| Setup.exe | 2.5MB | compiles, has .rsrc (43KB, 7 resource types) |
| SetupLdr.exe | 215KB | compiles, has .rsrc (8KB, 5 resource types) |
| Compil32.exe | 2.3MB | compiles |

## Resource Verification

```
Setup.exe:    RT_BITMAP, RT_ICON, RT_RCDATA, RT_GROUP_ICON, RT_VERSION, RT_MANIFEST
SetupLdr.exe: RT_ICON, RT_RCDATA, RT_GROUP_ICON, RT_VERSION, RT_MANIFEST
```

RT_RCDATA #11111 (SetupLdrOffsetTable) confirmed present in SetupLdr.

## What Works Under Wine

1. ISCC.exe launches, shows version
2. ISCmplr.dll loads
3. .iss script parsing (all sections)
4. Wizard bitmap loading
5. "Preparing Setup program executable" — PrepareSetupE32 succeeds
6. Default.isl message loading
7. [LangOptions], [Messages], [CustomMessages] parsing
8. "Messages in script file" — ReadMessagesFromScript succeeds
9. **Access violation** — post-message processing

## Exception

```
code=c0000005 (EXCEPTION_ACCESS_VIOLATION)
addr=0x0153DBCF (inside ISCmplr.dll)
```

## Code Flow (Compile.pas)

```
line 8750: Read wizard images              <- OK
line 8759: PrepareSetupE32(SetupE32)       <- OK
line 8770+: ReadDefaultMessages            <- OK
line 8800+: ReadMessagesFromScript          <- OK
line 8810+: PopulateLanguageEntryData       <- CRASH (suspected)
```

## What Has Been Ruled Out

- Missing resources — all present, verified
- Missing RT_RCDATA #11111 — confirmed in SetupLdr
- fpcres LangID bug — BUG-032 fixed
- PE resource directory layout — PrepareSetupE32 succeeds
- fpc264irc wine fix commit b7b5254f — does not fix this crash

## Likely Cause

Wine ANSI string/codepage handling differs from real Windows.
The crash occurs in language data processing after message parsing.
FPC AnsiString implementation under Wine may behave differently.

## Next Step

Test on real Windows. If `ISCC.exe test.iss` produces test-setup.exe,
this is Wine-only and not a code bug.

---

## UPDATE: BUG-034 Fix Applied

**Fix commit:** syswin.inc patched with FPC_AnsiCodePage
**Date:** 2026-07-20

Root cause identified: Wine's GetACP() returns 65001 (UTF-8).
FPC's RTL uses CP_ACP in WideCharToMultiByte/MultiByteToWideChar,
which under Wine resolves to UTF-8. Delphi-era AnsiString code
expects single-byte ANSI (1252). UTF-8 multi-byte conversion
corrupts string buffer sizes → memory corruption → AV.

**Fix:** Replaced CP_ACP with FPC_AnsiCodePage variable in syswin.inc.
Initialized at startup by InitAnsiCodePage:
1. GetACP() returns 65001 → detect Wine environment
2. Check FPC_ALLOW_UTF8_ACP env var (opt-in override)
3. Fall back to GetLocaleInfoA(LOCALE_IDEFAULTANSICODEPAGE)
4. If that fails → default to 1252 (Western European)

**Status:** Fix in source. Requires RTL rebuild to take effect.
Inno team needs to rebuild all 5 targets against patched RTL.

---

## UPDATE 2: Real Root Cause Found — BUG-035

**NOT a codepage issue.** BUG-034 was a red herring.

### Crash Location
`COMPRESS_UPDATECRC32` at RVA 0x3DBCF in ISCmplr.dll
Assembly: `mov 0x9435f0(,%eax,4),%eax` — CRC32 table lookup
eax = 0x4C58 (19544) — WAY out of bounds (max 255)

### Root Cause: FPC Lo() returns Word, not Byte
```
Compress.pas line 152:
  CRC32Table[Lo(CurCRC) xor P^] xor (CurCRC shr 8);

Delphi: Lo(LongInt) → Byte  (low 8 bits)  → index 0-255
FPC:    Lo(LongInt) → Word  (low 16 bits)  → index 0-65535
```

CRC32Table is `array[Byte]` (256 entries). FPC produces a
Word-sized XOR result that overflows the array → reads unmapped
memory → Access Violation.

### Fix (Inno-side, one line)
```pascal
// BEFORE:
CRC32Table[Lo(CurCRC) xor P^] xor (CurCRC shr 8);
// AFTER:
CRC32Table[Byte(CurCRC) xor P^] xor (CurCRC shr 8);
```

### Lo() Audit (8 usages in Inno)
Only Compress.pas:152 is critical. All other Lo() usages are
comparisons or small-value assignments that work with Word result.

### Impact
This crash occurs on ALL platforms (Wine and real Windows).
It is not Wine-specific. Every attempt to compile a .iss script
will crash at the compression stage.

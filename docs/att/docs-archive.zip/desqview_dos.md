# DOS + DESQview Setup — Mystic BBS Multi-Node

## Overview

Mystic BBS on DOS uses DESQview (DV) for multitasking. Each component
runs in its own DV window as a separate DOS task. QEMM provides
memory management, and TCP/IP runs via Wattcp or Trumpet.

## Software Stack

| Component | Version | Purpose |
|-----------|---------|---------|
| DESQview | 2.8 | Multitasker (window/task management) |
| DV/X | 2.10 | X Window System for DOS (optional GUI) |
| QEMM | 97 | Memory manager (EMS/XMS/UMB/DPMI) |
| TCP4DOS | — | TCP/IP stack (alternative to Wattcp) |
| Trumpet | 1.607 | TCP/IP stack (alternative) |
| Wattcp | — | Waterloo TCP/IP (used by MIS) |
| BNU/X00 | — | FOSSIL serial driver |
| Packet driver | — | NE2000/3C509 Ethernet |

All available in `sdk/desqview/`.

## Architecture

```
╔══════════════════════════════════════════════════════╗
║  DESQview 2.8                                        ║
╠══════════════════════════════════════════════════════╣
║                                                      ║
║  ┌──────────────────┐  ┌──────────────────┐          ║
║  │ Window 1: MIS    │  │ Window 2: Node 1 │          ║
║  │                  │  │                  │          ║
║  │ Wattcp TCP/IP    │  │ mystic -TID1     │          ║
║  │ Telnet :23       │  │ (user session)   │          ║
║  │ FTP    :21       │  │                  │          ║
║  │ BINKP  :24554    │  └──────────────────┘          ║
║  │                  │  ┌──────────────────┐          ║
║  │ Spawns nodes     │  │ Window 3: Node 2 │          ║
║  │ via -TID<handle> │  │ mystic -TID2     │          ║
║  └──────────────────┘  └──────────────────┘          ║
║                                                      ║
║  ┌──────────────────┐                                ║
║  │ Window N: Modem  │  ← Optional, separate from MIS ║
║  │                  │                                ║
║  │ mystic_modem     │                                ║
║  │ Watches COM1     │                                ║
║  │ On RING: spawns  │                                ║
║  │ mystic -COM1     │                                ║
║  │        -FOSSIL   │                                ║
║  └──────────────────┘                                ║
║                                                      ║
╠══════════════════════════════════════════════════════╣
║  QEMM 97 — EMS/XMS/UMB/DPMI                         ║
║  Packet Driver — NE2000/3C509                        ║
║  FOSSIL — BNU 1.91 or X00 1.50                       ║
╚══════════════════════════════════════════════════════╝
```

## CONFIG.SYS

```
DEVICE=C:\QEMM\QEMM386.SYS RAM ROM ST:M
DEVICE=C:\QEMM\LOADHI.SYS /R:2 C:\DV\QEMM\DVA.SYS
DOS=HIGH,UMB
FILES=60
BUFFERS=30
STACKS=9,256
LASTDRIVE=Z
DEVICE=C:\QEMM\LOADHI.SYS /R:1 C:\FOSSIL\BNU.SYS /D:2
```

### Key settings:
- `QEMM386.SYS RAM ROM ST:M` — Stealth mode, maximum UMB space
- `DVA.SYS` — DESQview adapter (must load in UMB via LOADHI)
- `BNU.SYS /D:2` — FOSSIL driver, 2 COM ports
- `FILES=60` — enough for multi-node BBS

## AUTOEXEC.BAT

```bat
@ECHO OFF
SET PATH=C:\DOS;C:\DV;C:\MYSTIC;C:\WATTCP
SET DVSYSTEM=C:\DV
SET DVPATH=C:\DV
SET WATTCP.CFG=C:\WATTCP

REM Load packet driver (NE2000 example)
C:\PACKET\NE2000.COM 0x60 3 0x300

REM Load FOSSIL
C:\FOSSIL\BNU.COM /L0:57600

REM Start DESQview
C:\DV\DV.COM
```

## WATTCP.CFG

```ini
# Wattcp configuration for MIS
my_ip=192.168.1.100
netmask=255.255.255.0
gateway=192.168.1.1
nameserver=8.8.8.8
domain=bbs.local
hostname=mysticbbs

# Socket settings
SOCKETS=32
MSS=1460
MTU=1500
```

## DV Window Configurations

### MIS Window (PIF/DVP)

```
Program:     C:\MYSTIC\MIS.EXE
Parameters:  
Directory:   C:\MYSTIC
Memory:      512KB conventional + 4096KB XMS
Writes text directly to screen: Y
Virtualize: All
Close on exit: N
Share CPU when in foreground: Y
```

### Node Window (spawned by MIS)

```
Program:     C:\MYSTIC\MYSTIC.EXE
Parameters:  -TID%1
Directory:   C:\MYSTIC
Memory:      384KB conventional + 2048KB XMS
Writes text directly to screen: Y
Close on exit: Y
```

### Modem Front-End Window

```
Program:     C:\MYSTIC\MYSTIC_MODEM.EXE
Parameters:  
Directory:   C:\MYSTIC
Memory:      256KB conventional + 1024KB XMS
Writes text directly to screen: Y
Close on exit: N
```

## Mystic Command Line Flags

| Flag | Purpose |
|------|---------|
| `-TID<n>` | Telnet node handle (passed by MIS) |
| `-COM1` | Use COM1 for serial I/O |
| `-COM2` | Use COM2 |
| `-FOSSIL` | Use FOSSIL driver instead of direct UART |
| `-LOCAL` | Local console mode (no modem/telnet) |
| `-NODE<n>` | Force node number |

## How TIOFossil Works

```
Application → TIOFossil → INT 14h → FOSSIL Driver → UART → Modem
                          ↑
                    FPC mdl/m_io_fossil.pas
                    
INT 14h Functions Used:
  AH=00  Init port
  AH=01  Send character (with wait)
  AH=02  Receive character (with wait)
  AH=03  Get port status
  AH=04  Init driver
  AH=05  Deinit driver
  AH=08  Flush output
  AH=09  Purge output
  AH=0A  Purge input
  AH=0B  Send character (no wait)
  AH=0C  Receive character (no wait)
  AH=19  Break signal
```

## The Netmodem Bridge

`netmodem` bridges TCP/IP to FOSSIL — makes a telnet connection
appear as a modem to the BBS:

```
Internet → TCP/IP → Wattcp → netmodem → INT 14h → FOSSIL → mystic
                                ↑
                    Translates TCP to serial protocol
                    Provides AT command emulation
                    Handles RING/CONNECT/CARRIER
```

This allows Mystic to accept telnet connections on DOS without
modifying the BBS software. MIS handles this natively via Wattcp,
but netmodem is useful for other BBS software (RBBS, TAG, etc.)
that only supports FOSSIL.

## Memory Requirements

| Component | Conventional | XMS/EMS |
|-----------|-------------|---------|
| DOS + QEMM | ~40KB | — |
| DESQview | ~60KB (in UMB) | — |
| Packet driver | ~10KB (in UMB) | — |
| FOSSIL (BNU) | ~8KB (in UMB) | — |
| MIS | ~300KB | ~4MB |
| Each node | ~256KB | ~2MB |
| Modem front | ~128KB | ~1MB |

With QEMM loading drivers into UMB, ~550KB conventional free
per DV window. Enough for DJGPP-compiled Mystic (uses DPMI).

### QEMM Optimization

```
QEMM386.SYS RAM ROM ST:M FR:E000-EFFF HA:1
```

- `RAM` — fill UMBs with RAM
- `ROM` — shadow ROM to RAM (faster)
- `ST:M` — Stealth mode (hides QEMM from conventional)
- `FR:E000-EFFF` — exclude adapter ROM range
- `HA:1` — handle count for DV

Use `OPTIMIZE.COM` to auto-arrange LOADHI order.

## Packet Driver Notes

```bat
REM NE2000 compatible:
NE2000.COM 0x60 3 0x300
REM   0x60 = software interrupt
REM   3    = IRQ
REM   0x300 = I/O port

REM 3Com 3C509:
3C509.COM 0x60

REM Intel EtherExpress:
EXP16.COM 0x60
```

The packet driver provides the interface between the NIC and
TCP/IP stack. Software interrupt 0x60 is standard.

## DV API Pascal Bindings — Timeslice Yielding

```pascal
{ DV API calls via INT 15h }
procedure DV_Pause;
{ Yields timeslice to other DV windows }
var Regs: Registers;
begin
  Regs.AX := $1000;
  Intr($15, Regs);
end;

function DV_Get_Version: Word;
{ Returns DV version (AH=major, AL=minor) or 0 if not running }
var Regs: Registers;
begin
  Regs.CX := $4445;  { 'DE' }
  Regs.DX := $5351;  { 'SQ' }
  Regs.AX := $2B01;  { Get version }
  Intr($21, Regs);
  if Regs.AL <> $FF then
    Result := Regs.BX
  else
    Result := 0;
end;

procedure DV_Begin_Critical;
{ Prevent task switching (use sparingly) }
var Regs: Registers;
begin
  Regs.AX := $101B;
  Intr($15, Regs);
end;

procedure DV_End_Critical;
{ Allow task switching again }
var Regs: Registers;
begin
  Regs.AX := $101C;
  Intr($15, Regs);
end;
```

These should be called in Mystic's idle loops to yield CPU
time to other DV windows. Without yielding, one node hogs
the entire CPU.

## Legal Note

DESQview was developed by Quarterdeck Office Systems (1987-1998).
Quarterdeck was acquired by Symantec in 1998. DESQview was later
released freely by IBM. The software is freely distributable.

QEMM was also a Quarterdeck product, included in this archive
for completeness as the required memory manager for DV.

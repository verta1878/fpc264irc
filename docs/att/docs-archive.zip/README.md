# FPC 2.6.4irc r3.1

A maintained fork of Free Pascal Compiler 2.6.4, focused on cross-compilation
and retro platform support. Builds 60 Mystic BBS executables across 4 platforms
from a single Linux host.

## Platforms

| Target | Format | Compiler | Mystic | THD ScanPro |
|--------|--------|----------|--------|-------------|
| Linux (i386) | ELF32 | ppc386 -Tlinux | 15/15 ✅ | 649KB ✅ |
| Win32 (i386) | PE32 | ppc386 -Twin32 | 15/15 ✅ | 202KB ✅ |
| OS/2 EMX (i386) | MZ+a.out | ppc386 -Temx | 15/15 ✅ | 533KB ✅ |
| Darwin (i386) | Mach-O | ppc386 -Tdarwin | 15/15 ✅ | — |
| DOS (go32v2) | DJGPP COFF | ppc386 -Tgo32v2 | Compiles | 526KB ✅ |
| FreeBSD (i386) | ELF32 | ppc386 -Tfreebsd | Compiles | — |

## What Changed from Upstream FPC 2.6.4

- **BUG-029:** AnsiString header size fix (i386 ASM `sub $12,%eax`)
- **BUG-040:** OS/2 EMX linker flag fix (`-N` removed for ZMAGIC)
- **prt0.o:** Reassembled with emx-as (773 bytes, `_dos_init`/`_dos_syscall` defined)
- **Codepage backport:** `DefaultSystemCodePage` parameter on all string
  conversion MoveProc functions
- **82 codec units:** Image, audio, archive, print, and RIP format support
- **m_mouse.pas:** Cross-platform text-mode mouse (xterm/Win32/DOS/OS/2)
- **emxbind:** Pascal replacement for OS/2 executable packaging
- **crt1.o + libSystem stub:** Darwin link without 257MB SDK
- **303 EMX import stubs:** DOSCALLS (165) + EMXWRAP (107) + SO32DLL (31)
- **cctools/ld64:** Built from source for Darwin cross-linking

## THD ScanPro — GPLv3 Clean-Room Rebuild

File processor for BBS systems, rebuilt from the THDDOC.TXT specification.
Zero original source code reused.

| Feature | Status |
|---------|--------|
| Archive detection (14 formats by magic bytes) | ✅ |
| Archive extraction via marc-lib (ZIP/RAR/ARJ/LHA/ARC/SQZ/HYP/UC2) | ✅ |
| Virus scanning (ClamAV live, McAfee/F-PROT/TBSCAN hooks) | ✅ |
| Description (VENDINFO.DIZ > FILE_ID.DIZ > DESC.SDI > DESC.SDN) | ✅ |
| GIF spec (Width×Height×Colors from header) | ✅ |
| CRC duplicate detection (THDPRO.DUP) | ✅ |
| TUI (ANSI interface, CP437 box drawing) | ✅ |
| THDINSTL config wizard (THDPRO.CFG, 692 bytes) | ✅ |
| TESTINFO.DAT (2380 bytes, byte-compatible) | ✅ |
| Cross-platform (Linux/Win32/DOS/OS2) | ✅ |

## Repository Structure

```
bin/
  ppc386              i386 compiler (cross-compiles all targets)
  ppcx64              x86_64 compiler (host)
  units/
    i386-linux/       174 PPUs
    i386-win32/       588 PPUs
    i386-go32v2/      255 PPUs
    i386-freebsd/     160 PPUs
    i386-os2/         141 PPUs + 303 import stubs
    i386-darwin/      757 PPUs
    x86_64-linux/     PPUs
  tools/
    i386-emx/         OS/2 cross-tools (as, ld, ar, emxbind)
    i386-go32v2/      DOS cross-tools (as, ld, ar)
    i386-win32/       Win32 cross-tools

src/
  compiler/           FPC compiler source
  rtl/                Runtime library (all targets)
  packages/           Package units (paszlib, hash, fcl-*, etc.)
  tools/              emxbind.pas
  thdpro/             THD ScanPro (thdpro.pas + thdinstl.pas + shims)

sdk/
  emx/                EMX 0.9d (GPLv2) — OS/2 POSIX layer
  os2tk45/            IBM OS/2 Toolkit 4.5.2 — headers, libs, tools
  prt/                Print API drivers (6 units)
  MacOSX10.6.sdk/     Minimal Darwin SDK (crt1.o + libSystem stub)
  thdpro/             THD ProScan reference (THDDOC.TXT, TESTINFO.INC)
    marc-lib/         Archive library (11 units, GPLv3)
    scanners/         F-PROT 2.24a, McAfee 3.0.4, TBSCAN 2.8

mdl/                  Mystic Development Library (45 units)
docs/                 Documentation
```

## Quick Start

```bash
# Linux:
./build-linux.sh

# Win32:
./build-win32.sh

# OS/2 (requires emx-ld + emxbind):
./build-os2.sh

# DOS (requires DJGPP cross-tools):
./build-dos.sh

# Darwin (needs cctools — run once):
./build-ld64-toolchain.sh
SDK=sdk/MacOSX10.6.sdk ./build-darwin.sh
```

## OS/2 EMX Cross-Compilation Notes

FPC's `external 'DOSCALLS' index NNN` syntax generates `call` instructions
to `_$dll$doscalls$_index_NNN` symbols. On native OS/2, `emxbind` patches
these at load time. For cross-compilation, import stub archives (`.dll.a`)
provide the symbols at link time.

- `prt0.o` must be assembled with `emx-as` (not system `as`) — provides
  `_dos_init` and `_dos_syscall` EMX startup functions
- Link requires `--allow-multiple-definition` due to 6 embedded imports
  in each `.o` overlapping with `.dll.a` entries
- 303 total import stubs across 3 DLLs: DOSCALLS, EMXWRAP, SO32DLL

## Bugs

40 bugs tracked, 38 fixed, 2 deferred:
- **BUG-038:** SysTryResizeMem leak — deferred
- **BUG-039:** Heap lock ordering — deferred

See `docs/bugsfixed.md` for full list.

## Codec Package

82 standalone units (8.3 filenames, GPLv3):
- Image: BMP, GIF, ICO, JPEG, PCX, PNG, PNM, TGA, TIFF
- Audio: WAV, AIFF, AU, FLAC, MP3, OGG, MIDI, MOD, S3M, XM, IT
- Archive: ZIP, RAR, ARJ, LHA, ARC, SQZ, HYP, UC2, GZ, BZ2, 7Z
- Graphics: Bezier, fill, clip, texmap, tile, sprite, delta
- Print: RAW, BMP, ESC/P, PCL5, PostScript, API
- RIP: Decoder, binder, layer, render, tile, delta

## Standalone Packages

| Package | Contents |
|---------|----------|
| thdpro-v100-gplv3.zip | THD ScanPro suite (15 binaries, 3 platforms) |
| fpc-codecs-standalone-gplv3-20260721.zip | Codec library (82 units) |
| m_mouse.pas | Cross-platform text-mode mouse |
| fpc264irc-r31-desqview-20260724.zip | DESQview 2.8 + DV/X 2.10 + QEMM 97 |

## License

GPLv3. FPC 2.6.4 is GPLv2 "or any later version" — this fork exercises
the upgrade clause. EMX SDK remains GPLv2 (compatible). See LICENSE.

## The Crew

| Handle | Role |
|--------|------|
| verta1878 | Project lead, architect |
| sysop/0 | Compiler engineer, fpc264irc maintainer |
| evga | Display, Mystic monitor |
| wrench | Build machine |

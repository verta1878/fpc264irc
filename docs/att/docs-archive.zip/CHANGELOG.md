# CHANGELOG — fpc264irc r3.1

## Changes from upstream FPC 2.6.4

### Compiler Fixes
- **BUG-029:** i386 ASM AnsiString Decr_Ref: `sub $12,%eax` (was `sub $8`)
  Fixed header size calculation for TAnsiRec (CodePage+ElementSize+Ref+Length)
- **BUG-040:** t_emx.pas: Removed `-N` flag from OS/2 EMX linker command
  (OMAGIC → ZMAGIC for emxbind compatibility)

### RTL Codepage Backport
Added `DefaultSystemCodePage` parameter to all widestringmanager MoveProc
functions across 6 source files:
- `ustringh.inc` — MoveProc type declarations
- `ustrings.inc` — UnicodeString conversion implementations
- `wstringh.inc` — WideString forward declarations
- `wstrings.inc` — WideString implementations (lines 552, 654 fixed)
- `text.inc` — Text file codepage handling
- `compproc.inc` — Compiler procedure declarations
- `win/sysutils.pp` — Win32 Wide2AnsiMoveProc (lines 1135, 1137)

### New Tools
- `src/tools/emxbind.pas` — Pascal emxbind replacement (MZ stub + a.out)
- `src/tools/emxbind.c` — C version (removed, Pascal is authoritative)
- `bin/tools/i386-emx/emxbind.py` — Python version (removed)
  All three produce identical output: SHA256 `1c47d0bf...`

### New Units
- `mdl/m_mouse.pas` — Cross-platform text-mode mouse (303 lines)
  Linux: xterm ESC[M + SGR 1006
  Win32: Console API (ReadConsoleInput)
  DOS: INT 33h
  OS/2: MOU subsystem via EMXWRAP

### SDK Integration
- `sdk/emx/` — Full EMX 0.9d (5.7MB, GPLv2)
- `sdk/os2tk45/` — IBM OS/2 Toolkit 4.5.2 (16MB trimmed)
- `sdk/prt/` — Print API drivers (6 units)
- `sdk/MacOSX10.6.sdk/` — Minimal Darwin SDK (crt1.o + libSystem stub)

### Import Stub Generation
- 318 OS/2 EMX import stubs reverse-engineered from emx2.a format
  (DOSCALLS 165, EMXWRAP 102, SO32DLL 31, QUECALLS 8, MSG 4, NLS 4, SESMGR 4)
- Format: 32-byte a.out header + 2×12-byte nlist + string table
- Symbol prefix: underscore (`_$dll$doscalls$_index_273`)

### Darwin Cross-Compilation
- `-dFPC_USE_LIBC` flag required (libc path, not direct syscalls)
- `crt1.o` (584 bytes) with dyld_stub_binding_helper
- `libSystem.B.dylib` (1,820 bytes) Mach-O stub with 73 exported symbols
- cctools/ld64 built from source (Apple open-source, APSL)

### Codec Package
71 units (65 codecs + 6 print drivers) in 8.3 filename format:
- Image: BMP, GIF, ICO, JPEG, PCX, PNG, PNM, TGA, TIFF, XBM, XPM, SVG
- Audio: WAV, AIFF, AU, FLAC, MP3, OGG, MIDI, MOD, S3M, XM, IT
- Archive: ZIP, TAR, GZ, BZ2, LZH, ARJ, RAR, CAB, CPIO, RPM
- Print: RAW, BMP, ESC/P, PCL5, PostScript, API+dithering
- All compile on x86_64-linux + i386-linux + i386-win32 + i386-go32v2

### PPU Chain
- system.ppu rebuilt from source for 5 i386 targets + restored for x86_64
- Source timestamps set to Jan 2025 for checksum consistency
- All 6 targets: zero "checksum changed" warnings

### License
- Upgraded from GPLv2 to GPLv3 (exercising "or any later version" clause)
- EMX SDK: GPLv2 (compatible)
- OS/2 Toolkit: IBM proprietary (headers/libs for linking)

## Build Results

| Platform | Programs | Format |
|----------|----------|--------|
| Linux i386 | 15/15 | ELF32, statically linked |
| Win32 i386 | 15/15 | PE32, dynamically linked |
| OS/2 EMX i386 | 15/15 | MZ + ZMAGIC a.out |
| Darwin i386 | 15/15 | Mach-O, dynamically linked |

60 total executables from one cross-compiler on Linux.

### THD ScanPro Suite (Phase 25)
GPLv3 clean-room rebuild of THD ProScan from THDDOC.TXT specification.
5 programs × 3 platforms = 15 binaries. Standalone package: `thdpro-v100-gplv3.zip`

- `THDPRO` — Main scanner (archive test, virus scan, description import)
- `THDINSTL` — Configuration wizard (ClamAV, McAfee, F-PROT, TBSCAN paths)
- `THDPLUS` — BBS database updater (reads TESTINFO.DAT)
- `THDTERM` — Terminal wrapper (directory watch, auto-test, PASS/FAIL sort)
- `THDSELCT` — Interactive file selector (TUI with toggle/batch test)

### OS/2 EMX Link Pipeline (Phase 12 fixes)
- `prt0.o` reassembled with `emx-as` (773 bytes) — fixes `_dos_init`/`_dos_syscall`
- Import stub archives (`.dll.a`) required for cross-compilation — FPC generates
  `call _$dll$doscalls$_index_NNN` without `.stabs` import directives
- 303 import stubs: DOSCALLS (165) + EMXWRAP (107) + SO32DLL (31)
- Link flag: `--allow-multiple-definition` for 6 embedded imports overlapping `.dll.a`
- `emx2.a` no longer needed (prt0.o has its own startup code)

### Bug Status
- 40 bugs tracked, 38 fixed, 2 deferred
- BUG-038: SysTryResizeMem leak — deferred
- BUG-039: Heap lock ordering — deferred

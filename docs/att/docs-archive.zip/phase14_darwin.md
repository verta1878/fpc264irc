# Phase 14: Darwin — From No Tools to 15/15

## Background

FPC 2.6.4irc had 757 i386-darwin PPUs but no cross-linker and no SDK.
The original 257MB MacOSX10.6.sdk was too large for the repo.
This phase built the toolchain and minimal SDK from scratch.

## Root Cause: FPC_USE_LIBC

Darwin's Makefile passes `-dFPC_USE_LIBC` but we compile with ppc386
directly, skipping the Makefile. Without it:
- system.pp takes the FreeBSD syscall path (`{$I syscall.inc}`)
- BSD syscall.inc uses `_GLOBAL_OFFSET_TABLE_` (ELF-only, invalid on Mach-O)
- system.o exports `FPC_DOSYS0-8` as undefined symbols
- Link fails: "symbol(s) not found"

**Fix:** Add `-dFPC_USE_LIBC` to all Darwin compile commands.
With it, system.pp uses libc (oscdecl.inc) → standard `_open`, `_read`, etc.

## Toolchain

### cctools/ld64 (built from source)
```bash
./build-ld64-toolchain.sh ~/darwin-xtools
```
Produces: i386-darwin-{ld,as,ar,nm,strip,ranlib}
Source: Apple open-source cctools-port (APSL license)

### crt1.o (584 bytes)
Minimal Mach-O startup code:
- `start` entry point (stack setup, call _main)
- `dyld_stub_binding_helper` (required by ld64)
- `_NXArgc`, `_NXArgv`, `_environ`, `___progname` globals

### libSystem.B.dylib (1,820 bytes)
Mach-O i386 dylib stub with 73 exported libc symbols.
Structure: MH header + LC_SEGMENT(__TEXT) + LC_ID_DYLIB + LC_SYMTAB +
LC_DYSYMTAB + LC_UUID + text(4 bytes) + nlist(73 entries) + strtab.

Replaces the 257MB Apple SDK for cross-linking purposes.

## Build Flags

```bash
ppc386 -Tdarwin -dFPC_USE_LIBC \
  -FD~/darwin-xtools/bin -XPi386-darwin- \
  -XR$SDK \
  -k-undefined -kdynamic_lookup \
  program.pas
```

- `-dFPC_USE_LIBC` — use libc, not direct syscalls
- `-XR$SDK` — sysroot for library/crt1.o search
- `-k-undefined -kdynamic_lookup` — lazy symbol resolution
- `-FD` + `-XP` — cross-tool path and prefix

## Results

| Program | Size (bytes) | Format |
|---------|-------------|--------|
| mystic | 1,600,808 | Mach-O i386 |
| mis | 1,380,168 | Mach-O i386 |
| mutil | 2,139,184 | Mach-O i386 |
| fidopoll | 1,243,808 | Mach-O i386 |
| marc | 1,080,968 | Mach-O i386 |
| nodespy | 821,016 | Mach-O i386 |
| qwkpoll | 1,200,116 | Mach-O i386 |
| mide | 538,224 | Mach-O i386 |
| mbbsutil | 525,088 | Mach-O i386 |
| mplc | 459,972 | Mach-O i386 |
| install | 387,204 | Mach-O i386 |
| 109to110 | 388,448 | Mach-O i386 |
| mystpack | 375,100 | Mach-O i386 |
| maketheme | 358,460 | Mach-O i386 |
| install_make | 352,932 | Mach-O i386 |

15/15 linked. All valid Mach-O i386 executables.

## SDK Size Comparison

| Component | Full Apple SDK | Our Stub SDK |
|-----------|---------------|-------------|
| Total | 257 MB | 2.4 KB |
| crt1.o | ~4 KB | 584 bytes |
| libSystem.B.dylib | ~2 MB | 1,820 bytes |
| Headers | 200+ MB | Not needed |
| Frameworks | 50+ MB | Not needed |

## Pending

- Phase 24: Runtime test on macOS (needs Mac hardware)

# INSTALL — Building with fpc264irc

## Prerequisites

- Linux x86_64 host (Ubuntu 22+, Debian 12+, or similar)
- The fpc264irc repo (this directory)
- For Darwin: cmake, ninja-build, clang or g++

## Linux (i386)

```bash
./build-linux.sh
# Output: out-linux/bin/ (15 ELF32 executables)
```

Uses ppc386 cross-compiler with i386-linux units. Statically linked.

## Win32 (i386)

```bash
./build-win32.sh
# Output: out-win32/bin/ (15 PE32 .exe files)
```

Uses ppc386 with i386-win32 cross-tools and units. Dynamically linked.

## OS/2 EMX (i386)

```bash
./build-os2.sh
# Output: out-os2/bin/ (15 MZ+a.out .exe files)
```

Build process:
1. ppc386 -Temx compiles to .s (assembly)
2. i386-emx-as assembles to .o (a.out objects)
3. i386-emx-ld links to .out (a.out executable)
4. Post-link: patch mtype byte (offset 2) from 0x64 to 0x00
5. emxbind wraps .out in MZ stub → .exe

The .exe runs on OS/2 with EMX runtime (emx.dll) installed.

Key flags:
- `-dFPC_USE_LIBC` is NOT used for OS/2 (direct syscalls via EMXWRAP)
- `-N` flag removed from linker (BUG-040: OMAGIC → ZMAGIC)
- 318 import stubs generated in EMX a.out format

## Darwin / macOS (i386)

### One-time: Build cross-toolchain

```bash
# Install dependencies:
apt-get install cmake ninja-build clang llvm-dev

# Build cctools/ld64:
./build-ld64-toolchain.sh ~/darwin-xtools
```

### Build

```bash
FPC=bin/ppc386 \
SDK=sdk/MacOSX10.6.sdk \
DARWIN_XTOOLS=~/darwin-xtools \
./build-darwin.sh
# Output: out_darwin/bin/ (15 Mach-O i386 executables)
```

Key flags:
- `-dFPC_USE_LIBC` required (Darwin uses libc, not direct INT 0x80)
- `-XR$SDK` sets sysroot for library search
- `-k-undefined -kdynamic_lookup` for lazy symbol resolution
- External assembler required (FPC's internal Mach-O rejected by ld64)

The minimal SDK (2KB) replaces the full 257MB MacOSX10.6.sdk:
- `crt1.o` (584 bytes) — startup code + dyld_stub_binding_helper
- `libSystem.B.dylib` (1,820 bytes) — 73-symbol Mach-O stub

## DOS (go32v2)

Compiles but not currently built by default. Needs DOSBox or real DOS
for testing.

```bash
ppc386 -Tgo32v2 -Fubin/units/i386-go32v2 program.pas
```

## Verify

```bash
# SHA256 checksums:
sha256sum out-linux/bin/*
sha256sum out-win32/bin/*.exe
sha256sum out-os2/bin/*.exe
sha256sum out_darwin/bin/*

# Compare sizes across platforms:
# Linux ~1.5MB, Win32 ~0.5MB, OS/2 ~1.4MB, Darwin ~1.5MB (for mystic)
```

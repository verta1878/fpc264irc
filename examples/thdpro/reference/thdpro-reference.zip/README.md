# THD ProScan v12.3 — Reference Archive

BBS file processor by David Muir (PainSoft), 1992-1996.
The only tool of its kind. No longer maintained by the author.

Included as reference material for the GPLv3 clean-room rebuild
(Phase 25). No original code is reused — only the documentation
(THDDOC.TXT, TESTINFO.INC) serves as the feature specification.

## Key Files

| File | Purpose |
|------|---------|
| THDDOC.TXT | 156KB documentation (feature spec) |
| TESTINFO.INC | TESTINFO.DAT format specification |
| TESTINFO.H | C header for TESTINFO.DAT |
| THDPRO.EXE | DOS executable (reference only) |
| THDSETUP.TXT | Configuration reference |
| HISTORY.DOC | Version history |
| NOTES.OS2 | OS/2 port notes |

## Original License

Copyright 1992-1996 PainSoft (David Muir). Freeware.
Distribution of the complete archive is permitted.
No modifications to the original files.

## Phase 25 Plan

Clean-room GPLv3 rebuild in Pascal using THDDOC.TXT as spec.
Same UI, same command-line flags, same TESTINFO.DAT format.
100% new code. Cross-platform (DOS/Linux/Win32/OS2).

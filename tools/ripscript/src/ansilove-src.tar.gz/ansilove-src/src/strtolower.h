/*
 * strtolower.h
 * Ansilove 4.2.2
 * https://www.ansilove.org
 *
 * Copyright (c) 2011-2026 Stefan Vogt, Brian Cassidy, and Frederic Cambus
 * All rights reserved.
 *
 * Ansilove is licensed under the BSD 2-Clause license.
 * See LICENSE file for details.
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */

#ifndef STRTOLOWER_H
#define STRTOLOWER_H

/* In-place modification of a string to be all lower case. */

char	*strtolower(char *);

#endif /* STRTOLOWER_H */

dir ..

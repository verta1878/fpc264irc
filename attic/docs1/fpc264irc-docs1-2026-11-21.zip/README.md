# FPC 2.6.4irc r311

Free Pascal Compiler — IRC/BBS Toolchain Edition

## What Is This

A complete Pascal development environment rebuilt from FPC 2.6.4 source,
targeting retro computing: BBS systems, DOS, Win9x, and cross-platform
console applications. Includes native x64 compiler, USB stack, and
Lazarus IDE with LCL widgetset.

## Platforms

| Target | Compiler | PPUs | Usage |
|--------|----------|------|-------|
| Win64 | ppcx64 | 1,039 | `ppcx64 -Twin64 myapp.pas` |
| Win32 (default) | ppc386 | 1,538 | `ppc386 -Twin32 myapp.pas` |
| Win9x ANSI | ppc386 | 1,538 | `ppc386 -Twin32 myapp.pas` (default=ANSI) |
| Linux x86_64 | ppcx64 | 632 | `ppcx64 -Tlinux myapp.pas` |
| Linux i386 | ppc386 | 275 | `ppc386 -Tlinux myapp.pas` |
| DOS (go32v2) | ppc386 | 318 | `ppc386 -Tgo32v2 myapp.pas` |
| DOS 16-bit | ppcross8086 | 114 | `ppcross8086 -Tmsdos myapp.pas` |
| FreeBSD i386 | ppc386 | 191 | `ppc386 -Tfreebsd myapp.pas` |
| FreeBSD x86_64 | ppcx64 | 74 | `ppcx64 -Tfreebsd myapp.pas` |
| macOS i386 (10.4 – 10.14) | ppc386 | 809 | `ppc386 -Tdarwin -FDbin/tools/i386-darwin -XRbin/tools/i386-darwin/MacOSX10.6.sdk myapp.pas` |
| macOS x86_64 (10.5 – 26, Rosetta 2) | ppcx64 | 789 | `ppcx64 -Tdarwin -FDbin/tools/i386-darwin -XRbin/tools/i386-darwin/MacOSX10.6.sdk myapp.pas` |

## What's Included

- **ppcx64** — native 64-bit Pascal compiler (3-stage bootstrapped, ELF64)
- **ppc386** — 32-bit Pascal compiler (FPC 2.6.4 core)
- **ppcross8086** — 16-bit cross-compiler (DOS real mode)
- **lazarus.exe** — Lazarus IDE (18 MB, LCL Win32 widgetset)
- **14 FPC tools** — fpcmake, fpcres, h2pas, ppudump, etc.
- **USB stack** — 9 units: usbcore, usbpci, usbhid, usbtrans, usbxhci, usbhub, usbmsd, libusb, usbserial
- **fpGUI toolkit** — lightweight alternative to LCL
- **Complete source** — RTL, packages, compiler, LCL, IDE

## Key Features

- **Native x64 compiler** — 4 compiler patches fix FPC 2.6.4's x64 codegen; 1,012 Win64 PPUs from unmodified source
- **USB stack** — FTDI/CH340/CP2102/PL2303 serial adapters, mass storage, HID, hub, xHCI controller
- **IUnknown native** — const keyword works, no CORBA hack needed
- **Win9x compatible** — win32compat.pas ANSI backport (U-1)
- **glibc 2.34+ fix** — dl.o reimplemented for modern Linux
- **Zero RTL workarounds** — all x64 fixes are compiler-level, RTL source is unmodified

## Quick Start

```
ppc386 -Twin32 myapp.pas        # Windows 32-bit
ppcx64 -Twin64 myapp.pas        # Windows 64-bit
ppc386 -Tlinux myapp.pas        # Linux 32-bit
ppcx64 -Tlinux myapp.pas        # Linux 64-bit
ppc386 -Tgo32v2 myapp.pas       # DOS
```

`bin/ppc386`, `bin/ppcx64`, `bin/ppcross8086` and the `bin/tools/*` programs are Linux x86_64 programs. A git clone
has them executable; after extracting a zip (zip drops the Unix execute bit) run `bash fix-permissions.sh` once.
List: `tools/smartpack/exec-bits.txt`.

### How the units ship

`bin/units/<target>/` holds each unit as `.ppu` + `.a` (its compiled code in a smart-link archive) — no loose `.o`.
The compiler picks up the `.a` by itself, with or without `-XX`. The only `.o` files left are startup objects the
compiler links by name (`prt0`, `cprt0`, `gprt0`, `dllprt0`, OS/2 `prt1`, go32v2 `exceptn`/`fpu`, i8086 `prt0*`).
Tested linking: i386/x86_64 Linux, Win32/Win64, go32v2, i386 FreeBSD, ptcgraph from the repo units alone.
Graph on 64-bit: x86_64-linux has no `graph` unit (FPC builds it for Linux/i386 only) - use `ptcgraph` there;
x86_64-darwin has none (Carbon is 32-bit). On both, `uses graph` stops with a message that names the fix. Per-target
table (win64, linux, freebsd, darwin) in `tools/graph-322-build/README.md`; test: `test/x64graph`.
i386-os2 links natively with `-FD bin/tools/i386-os2` (see its README); i386-darwin and x86_64-darwin with
`-FD bin/tools/i386-darwin` (`docs/DARWIN-CROSS.md`). Kit and details: `tools/smartpack/README.md`.

## USB Stack

9 units, 3,334 lines. See `docs/USB.md` for full API reference.

```pascal
uses USBSerial;
var Dev: TUSBSerialDevice;
begin
  USBSerialOpen($0403, $6001, Dev);   { FTDI FT232 }
  USBSerialSetBaud(Dev, 115200);
  USBSerialSetLineParams(Dev, 8, 1, 0);
  { ... read/write ... }
  USBSerialClose(Dev);
end.
```

*More serial examples coming — see docs/USB.md.*

## 16-bit DOS (Real Mode)

`ppcross8086` compiles Pascal to 16-bit DOS .EXE files that run on original
IBM PC hardware — 8086, 286, 386, no DPMI extender, no protected mode.
Real mode, 640K, the way it was. `ppcross8086` (FPC 3.2.2) is a Linux program - there is no Windows
`ppcross8086.exe` yet, so build 16-bit programs on Linux (or WSL).

```
ppcross8086 -Tmsdos -WmSmall -XX -Fubin/units/i8086-msdos-small myapp.pas
```

**Important:** Always use `-XX` (smart linking) and `-Fu` pointing to the
model-specific unit directory. Without `-XX`, the linker looks for `.o` files
that don't exist — the units are stored in `.a` archives that only smart
linking can read.

| Flag | What it does |
|------|-------------|
| `-WmSmall` | Select memory model (Tiny/Small/Medium/Compact/Large/Huge) |
| `-XX` | Smart linking — **required**, reads .a archives |
| `-Fubin/units/i8086-msdos-small` | Unit search path (match the model) |
| `-CX` | Create smart-linked units (only needed when recompiling RTL) |
| `-Wh` | Huge code for units you compile yourself (optional; `ppcross8086 -h`: "ignored for models with CODE in a unique segment"); programs do not need it |

Quick reference:
```
# Tiny (single segment, .COM-like):
ppcross8086 -Tmsdos -WmTiny -XX -Fubin/units/i8086-msdos-tiny myapp.pas

# Small (default, near code+data):
ppcross8086 -Tmsdos -WmSmall -XX -Fubin/units/i8086-msdos-small myapp.pas

# Large (far code+data, bigger programs):
ppcross8086 -Tmsdos -WmLarge -XX -Fubin/units/i8086-msdos-large myapp.pas

# Huge (far code+data, huge pointers):
ppcross8086 -Tmsdos -WmHuge -XX -Fubin/units/i8086-msdos-huge myapp.pas
```

**classes** (TStringList etc.): links in Medium and Large and with the default `bin/units/i8086-msdos` set (huge
model, `-Wmhuge`) since 2026-11-21 (BUG-052). Tiny/Small/Compact: one 64KB code segment, too small; the `-huge`
folder's `system` is 94 bytes too big with it - use the default set. Open: BUG-053 (Large/Huge, copying a record
with two AnsiStrings corrupts memory) - `docs/bugsfixed.md`.

Pre-compiled units (`.ppu` count, 2026-11-21): tiny/small/compact 23, medium/large/huge 48 (+ graph and Free Vision),
the default `i8086-msdos` set 115 - system, dos, crt, objects, strings, sysutils, classes, mouse, keyboard, video, and more.

**Graph (BGI-style):** `graph` unit for Medium, Large and Huge models
(plus the default `i8086-msdos` set). CGA, EGA, VGA, mode 13h and VESA
(256-colour and hi-colour) — tested in DOSBox. Not available for Tiny,
Small or Compact: graph + RTL does not fit in one 64KB code segment.
```
ppcross8086 -Tmsdos -WmLarge -XX -Fubin/units/i8086-msdos-large myapp.pas
```
**Free Vision:** the 24 Free Vision units for Medium, Large and Huge (and the default
`i8086-msdos` set), tested in DOSBox. Not for Tiny, Small or Compact: a Free Vision
program needs about 150KB of code.

Build kit and test results: `tools/i8086-graph-build/`.

Works with: IBM PC/XT/AT, Tandy, PCjr, DOSBox, 86Box, real hardware.
Output: 16-bit MZ .EXE (not NE, not PE, not DJGPP).

All 6 memory models supported: Tiny, Small, Medium, Compact, Large, Huge.
22 units per model including system, dos, crt, sysutils, objects, keyboard,
mouse, video, printer, math, typinfo, fgl, classes, and more; Medium, Large
and Huge add graph and Free Vision (47 units).

**Important:** Each model has its own unit directory. You MUST use the
matching directory and pass `-XX` (smart linking) or compilation will fail
with "Can't open object file" errors:

```
ppcross8086 -Tmsdos -WmTiny    -XX -Fubin/units/i8086-msdos-tiny    program.pas
ppcross8086 -Tmsdos -WmSmall   -XX -Fubin/units/i8086-msdos-small   program.pas
ppcross8086 -Tmsdos -WmMedium  -XX -Fubin/units/i8086-msdos-medium  program.pas
ppcross8086 -Tmsdos -WmCompact -XX -Fubin/units/i8086-msdos-compact program.pas
ppcross8086 -Tmsdos -WmLarge   -XX -Fubin/units/i8086-msdos-large   program.pas
ppcross8086 -Tmsdos -WmHuge    -XX -Fubin/units/i8086-msdos-huge    program.pas
```

Do NOT use `bin/units/i8086-msdos/` directly — it contains legacy archives
without individual .o files. Always use the model-specific directories above.

**Choosing a model:**

| Model | Code | Data | Best for |
|-------|------|------|----------|
| Tiny | 64K shared | (with code) | .COM files, TSRs |
| Small | 64K | 64K | Simple utilities, serial tools |
| Medium | multiple | 64K | Large code, small data |
| Compact | 64K | multiple | Small code, large data |
| Large | multiple | multiple | Large programs |
| Huge | multiple | multiple | Everything, no limits (498K+ with classes) |

Small is the default and works for most serial/console programs.
Use Huge if you need `classes` (TList, TStringList) — it exceeds 64K
on all other models (hardware segment limit, same as stock FPC 3.2.2).
`classes` compiles for all 6 models but links on Huge only — code+data exceed
the 64K segment limit on smaller models (hardware limit, same as stock FPC 3.2.2).
Use `objects` (TCollection, TStream — 17K) instead of `classes` (TList — 498K)
on Tiny/Small/Medium/Compact/Large. Built from FPC 3.2.2 source with `ppcross8086` 3.2.2.

## x64 Compiler Bootstrap

4 patches to `src/compiler/`, 3-stage build. See `docs/X64-BOOTSTRAP.md`.

```
bin/ppc386 → ppcx64 (i386 binary) → ppcx64 (native ELF64)
```

| Patch | Fix |
|-------|-----|
| `defutil.pas` | Ordinal range check demoted to warning |
| `nopt.pas` | Multi-string concat optimization disabled |
| `symdef.pas` | ICE 99080501 + 200204176 graceful fallback |
| `fppu.pas` | Timestamp/CRC bypass for bootstrap |

## Tests

7 compilation tests verify the rebuilt PPU chain:

1. IUnknown native const (no CORBA hack)
2. fpjson + jsonparser
3. DOM + XMLRead
4. classes + typinfo RTTI
5. registry (Win32)
6. fphttpclient (network)
7. test_usb (USB stack)

## The Crew

| Handle | Role |
|--------|------|
| verta1878 | Project lead |
| sysop/0 | Compiler engineer, FPC, Tang Console, USB |
| bob | Compiler engineer, OpenWatcom2 x64, Glide, 3dfx drivers |
| evga | Display, Mystic, SIO rebuild |
| kiddo | Protocols, RIPscrip |
| wrench | Transport, FOSSIL, serial |
| hexadecimal | PCBoard, Cyclades |
| DotMatrix | Documentation sourcing |
| byte | Program discovery |

the crew 4free — x86 little endian

## Serial Unit — Cross-Platform

9 platforms, 26 unified functions. `uses Serial;` works everywhere.

| Platform | Backend |
|----------|---------|
| x86_64-linux, i386-linux | termios (ioctl) |
| x86_64-win64, i386-win32 | Windows COM API |
| x86_64-freebsd, i386-freebsd | termios (ioctl) |
| i386-darwin, x86_64-darwin | termios (ioctl) |
| i386-go32v2 | direct UART 8250/16550 |
| i386-os2 | DosDevIOCtl ASYNC |

26 functions: SerOpen, SerClose, SerRead, SerWrite, SerFlush,
SerSetParams, SerSaveState, SerRestoreState, SerSetDTR, SerSetRTS,
SerGetCTS, SerGetDSR, SerGetRI, SerGetCD, SerBreak, SerDrain, SerSync,
SerFlushInput, SerFlushOutput, SerReadTimeout, SerDataAvailable,
SerDetectUART, SerSetFIFO, SerGetBase, SerEnableIRQ, SerDisableIRQ.

Source: `src/rtl/unix/serial.pp` (Unix/BSD/Mac), `src/rtl/win/serial.pp` (Windows),
`src/rtl/os2/serial.pp` (OS/2), `src/packages/serial/serial.pp` (DOS).
Full reference: `docs/SERIAL.md`.
